module.exports = {
  content: ["./*.html"],
  theme: {
    extend: {},
  },
  pluggins: []
}